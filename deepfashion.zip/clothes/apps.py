from django.apps import AppConfig


class ClothesConfig(AppConfig):
    name = 'clothes'
